Trace Low-Voltage LED Status Board — five-faults variant
Single-sided, 42 x 30 mm, FR-4, 1.6 mm, 1 oz copper. 0.8 mm plated holes.
Layers: F_Cu, F_Mask, F_Silkscreen, Edge_Cuts, PTH drill.
Circuit: J1 supplies 5 V; R1 is 330 ohm; D1 is a red through-hole LED.
INTENTIONAL TEST FAULTS (five expected geometry findings):
1. Open trace: 1.00 mm gap in the R1-to-D1 series trace, near X 26.50 mm, Y 9.00 mm.
2. Open trace: 1.00 mm gap in the GND return trace, near X 24.50 mm, Y 21.00 mm.
3. Missing copper pad at the GND connector, X 6.00 mm, Y 21.00 mm.
4. Unexpected copper pad at X 30.00 mm, Y 21.00 mm.
5. Added copper bridge from +5 V to GND near X 20.31 mm; potential short, confirm with a netlist.
Do not fabricate this intentional-fault package.
These files are generated test artwork, not a manufacturer's validated production release. Review all layers and drill data in a Gerber viewer and run the fabricator's DFM checks before ordering.
