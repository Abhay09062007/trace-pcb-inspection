Trace Low-Voltage LED Status Board — copper-short variant
Single-sided, 42 x 30 mm, FR-4, 1.6 mm, 1 oz copper. 0.8 mm plated holes.
Layers: F_Cu, F_Mask, F_Silkscreen, Edge_Cuts, PTH drill.
Circuit: J1 supplies 5 V; R1 is 330 ohm; D1 is a red through-hole LED.
TEST FAULT: copper bridge between +5 V and GND. Do not fabricate as a functional board.
These files are generated test artwork, not a manufacturer's validated production release. Review all layers and drill data in a Gerber viewer and run the fabricator's DFM checks before ordering.
